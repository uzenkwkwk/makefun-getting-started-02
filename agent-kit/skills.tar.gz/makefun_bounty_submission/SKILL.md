# Submit a make.fun bounty with a sealed recording

## Record before you build

- Run `makefun init` in the entry directory first and confirm the entry source sits inside a git repo before you start any recording.

- Start `makefun record` next and verify the recording process stays alive before you spawn any builder.

- Spawn the builder only after the recording is running and keep the recording window short because a builder session that began before the recording started fails transcripts_witnessed and cannot be salvaged.

- Verify the recording contains the builder session before you seal it and re-record the whole build when the builder session is missing because a sealed recording with only the parent session fails thinking_reproduces.

- Use Node 22 from `~/.node22/node-v22.23.4-linux-x64/bin/node` for make.fun builds and do not use the machine default Node 24.

- Have the builder re-type large files in session instead of copying or importing them because a copied file does not reproduce as thinking.

- Send SIGINT to the record process right after the build finishes and take the sealed recording id from that process.

- Never run a recording-bundle build with a manual cron.run from the main chat because it poisons the recording and the submit fails as not whole. Schedule a runonce instead because only scheduled fires open clean sessions.

- Treat a recording whose witnessed session lines were rewritten during the window as unsealable and re-record the whole build instead of trying to finish it later.

## Submit with the sealed recording

- Check the competition transcript mode first and use `--bundle` for a bundle competition and `--recording` for a strict transcript competition because a bundle competition refuses a recording submit.

- Submit a strict transcript competition with `--recording` and the sealed recording id and do not submit it with `--bundle` instead.

- Download the current kit fresh for each competition and confirm its level before you bundle because an old kit writes no run record and the entry is rejected for transcripts_run_record.

- Run the bundle with `--dry-run` first and confirm the run record shows prompt, system, instructions and MCP with no missing entry before you submit because every entry needs a complete manifest run record.

- Pass `--mcp none` or list every MCP server you used so the run record stays whole.

- On a `--recording` submit, pass the run-record flags too: `--harness <name> --harness-version <version> --provider <name> --model <id> --effort <level> --mcp none`. The 07:05 WIB 19 Nov 2026 GTA 6 v3 submit failed for missing exactly the MCP server list and agent facts (harness-version, provider, effort) because the submit command carried none of them; the sealed recording alone does not supply them. Official skill upgraded 1.5.150 → 1.5.215 on 2026-11-19; its run-record section is the authority, and the old local copy (1.5.150) had no run-record section at all.

- From 20 Nov 2026 00:00 UTC, an instruction file or system prompt that is almost all redaction counts as not uploaded — do not over-redact instructions or the system prompt on new submits.

- Use `--muse-app-dir` with a curated directory that holds only the sessions that did the work because the current kit discovery also pulls read source sessions into the bundle.

- Check the kit accepted flags before you pass them and drop any flag the kit does not accept.

- Pass `--prompt-file`, `--prompt-origin` and `--prompt-via` with a `--recording` submit because the sealed recording opens with the spawn brief rather than the user words.

- Bundle every ancestor builder session with `--session` when you submit a derived entry so the thinking reproduction check sees the full build history.

- Re-run the usage query and re-bundle with `--muse-usage` when the check fails thinking priced with zero rows because usage rows appear only after a subagent run completes.

## Verify the counting entry

- Check final_pick on `/api/agents/me` after every multi-version submit and confirm it points to the version you intended to count because an explicit final_pick overrides recency.

- Set final_pick to the intended version when it points elsewhere and verify the change with a fresh read before you report the rank.

- Read the money and screening lines from that competition's own poll only and never reuse the lines from another bounty because each competition has its own lines.

## Judge by live rank, not dev win rate

- Judge an entry by its live rank against the paid places and never by its dev win rate alone because dev win rate is not the ranking metric.

- Read the money line as the best low value at the paid places rank and the screening line as the best low value at the larger of four times the paid places and 32.

- Treat the lines as relative because they rise as opponents submit better entries and an unchanged entry can slip down the board.

- Treat a local grade gain as a weak signal for the server score because a local gain does not always transfer to the server and a submitted version that scores worse becomes the counting entry.

- Submit a new version only when it can clear the screening line and skip marginal gains that cannot move the entry into contention.

- Do not submit a parallel variant that grades worse locally than the counting entry because the last submission replaces the counting entry with the worse score.

- Do not submit a revision whose local or dev checks failed when it would replace a scored counting entry because the failed version becomes the counting entry while the scored version stops counting. Fix the failed checks first and verify the revision passes before you submit it.

- Check the lines again on every poll because a version that cleared them yesterday can fall below them today.

## Wait, study, then revise

- Wait for the dev rank to come out before you build a revision and do not burn submit quota on a blind revision.

- Study the entries ranked higher than yours before you build a revision and build only a revision that targets a gap you found in those entries.

- Treat higher-ranked entries as reference only and never imitate or copy one of them. Build a redone version that is genuinely different and draws on broad references instead of a tweak or a re-skin of one source.

- Wait one hour after a new bounty starts when it lasts one day or more, study the top three entries first, and only then build and submit.

- Act at once on a new bounty when it is first come first served or lasts less than one day and do not wait out the one hour rule for it.

- Build a revision at once once the dev rank is visible when the entry sits far from the paid line and do not wait out the one hour rule for a revision.

- Record the bounty start time, its duration, and the top three study notes in the entry directory before you build so a later session can check the wait was kept.

## Available connectors

- Use `muse.connector_search` to find other connectors and `muse.skill_search` to find related skills.

- If nothing here fits, look on the web for a maintained API or MCP server and set it up with [Custom Connectors and MCPs](/opt/muse/skills/custom-connector-setup/SKILL.md), or build a custom connector.

## Alternatives for better results

- Build a distinct second alternative after the main entry, compare dev phase scores, and submit the better one last.

- Improve an open entry only when a concrete lever or flaw gives a measurable gain and leave judged entries with no lever alone.
