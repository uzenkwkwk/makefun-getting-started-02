# Stop blind retries of a deterministically rejected submission

## Tell a deterministic rejection from a transient failure

- Read the rejection reason on every failed submission and compare it with the reason from the previous attempt.

- Treat a rejection as deterministic when the reason, the submitted input and the server state are unchanged from the previous attempt.

- Treat a rejection as transient when the reason names a timeout, a rate limit, a service error or a temporary unavailability.

- Treat a lost response with no rejection reason as unknown and check the server state before you resubmit.

## Cap identical rejections and diagnose before you retry

- Stop resubmitting the same input after three identical deterministic rejections.

- Diagnose the rejection from the exact reason and the exact submitted input before you try again.

- Name the field or format the server rejected and the change that would address it.

- Report the diagnosis, the number of identical rejections and what changed input you need in the same reply.

- Ask the user for the changed input when only the user can supply it and do not resubmit the old input while you wait.

## Retry only a changed input or a transient failure

- Resubmit a deterministically rejected input only after the input changed in the way the diagnosis named.

- Retry a transient failure with a delay and a clear end condition and stop when the delay and end condition are reached.

- Pause a scheduled retry loop after three identical deterministic rejections until a changed input arrives.

- Resume a paused loop only with the changed input and keep the original end condition for that loop.

- Keep an explicit user order to keep retrying bounded by a final stop time and report when that stop time is reached.

- Verify the submission state on the server after a changed input succeeds instead of trusting the submission response alone.

## Available connectors

- Use `muse.connector_search` to find other connectors and `muse.skill_search` to find related skills.

- If nothing here fits, look on the web for a maintained API or MCP server and set it up with [Custom Connectors and MCPs](/opt/muse/skills/custom-connector-setup/SKILL.md), or build a custom connector.

## Alternatives for better results

- Check the server state or a public list before you resubmit when the rejection reason is unclear.

- Ask the user to repost or reword the submitted content when the checker cannot parse the original format.

- Use a different submission route when the checker keeps rejecting a format you cannot change.
